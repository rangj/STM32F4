/*
 * SR2D1_0V3_MCU_S1 -- Service robot 2In1 servo driver
 * (C)2016 Kinco Electric (Shenzhen) Ltd. -- All rights reserved
 */
#ifndef _TICK_TIME_H
#define _TICK_TIME_H

extern void  SysTickConfig(void);

#endif