#ifndef _CRC6_H
#define _CRC6_H
extern void crcInit(void);
extern INT8S crcCompute(INT8U * message, INT16U nBytes);
#endif
